import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, FlatList } from 'react-native';
import { AntDesign } from '@expo/vector-icons';

export default function App() {
  const [task, setTask] = useState('');
  const [taskList, setTaskList] = useState([
    { id: 1, name: 'Chụp ảnh', completed: false },
    { id: 2, name: 'Edit video', completed: false },
    { id: 3, name: 'Chuẩn bị thiết bị chụp ảnh', completed: false },
    { id: 4, name: 'Edit ảnh', completed: false },
  ]);
  const [filteredTaskList, setFilteredTaskList] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState('');

  const addTask = () => {
    if (task.trim() !== '') {
      const newTask = {
        id: new Date().getTime(),
        name: task,
        completed: false
      };
      setTaskList([...taskList, newTask]);
      setTask('');
    }
  };

  const toggleTask = id => {
    const updatedTaskList = taskList.map(task => {
      if (task.id === id) {
        return { ...task, completed: !task.completed };
      }
      return task;
    });
    setTaskList(updatedTaskList);
  };

  const deleteTask = id => {
    const updatedTaskList = taskList.filter(task => task.id !== id);
    setTaskList(updatedTaskList);
  };

  const searchTask = keyword => {
    setSearchKeyword(keyword);
    const filteredTasks = taskList.filter(task =>
      task.name.toLowerCase().includes(keyword.toLowerCase())
    );
    setFilteredTaskList(filteredTasks);
  };

  return (
    <View style={styles.container}>
      <View style={styles.innerContainer}>
        <Text style={styles.title}>TODO LIST</Text>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Thêm nhiệm vụ"
            value={task}
            onChangeText={setTask}
          />
          <TouchableOpacity style={styles.addButton} onPress={addTask}>
            <AntDesign name="plus" size={24} color="white" />
          </TouchableOpacity>
        </View>
        <TextInput
          style={styles.searchInput}
          placeholder="Tìm kiếm nhiệm vụ" 
          value={searchKeyword}
          onChangeText={searchTask}
        />
        <FlatList
          data={searchKeyword ? filteredTaskList : taskList}
          keyExtractor={item => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.taskContainer}>
              <TouchableOpacity style={styles.checkbox} onPress={() => toggleTask(item.id)}>
                {item.completed && <AntDesign name="check" size={24} color="green" />}
              </TouchableOpacity>
              <Text
                style={[styles.task, item.completed && styles.completedTask]}
              >
                {item.name}
              </Text>
              <TouchableOpacity style={styles.deleteButton} onPress={() => deleteTask(item.id)}>
                <AntDesign name="delete" size={18} color="white" />
              </TouchableOpacity>
            </View>
          )}
        /></View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#CCFFFF', 
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerContainer: {
    width: '80%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333', 
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginRight: 15,
    paddingHorizontal: 15,
    color: '#333', 
  },
  addButton: {
    backgroundColor: 'skyblue',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  searchInput: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    marginBottom: 20,
    paddingHorizontal: 10,
    color: '#333', 
  },
  taskContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  checkbox: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    padding: 5,
    marginRight: 10,
  },
  task: {
    flex: 1,
    fontSize: 16,
    color: '#333', 
  },
  completedTask: {
    textDecorationLine: 'line-through',
    color: 'gray', 
  },
  deleteButton: {
    backgroundColor: 'red',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 5,
  },
});
